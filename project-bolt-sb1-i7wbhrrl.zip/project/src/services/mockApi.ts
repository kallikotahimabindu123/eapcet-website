import { mockUser, mockExamMetadata, mockQuestions } from '../data/mockData';
import { User, ExamMetadata, Question, ExamResult, QuestionResult } from '../types';

// Simulate network delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const mockApi = {
  async login(email: string, password: string): Promise<{ token: string; user: User }> {
    await delay(1000);
    
    // For development: accept any credentials
    return {
      token: 'mock-jwt-token-' + Date.now(),
      user: {
        ...mockUser,
        email: email.trim()
      }
    };
  },

  async getExamMetadata(token: string): Promise<ExamMetadata> {
    await delay(500);
    
    if (!token) {
      throw new Error('Unauthorized');
    }
    
    return mockExamMetadata;
  },

  async getQuestions(token: string): Promise<Question[]> {
    await delay(800);
    
    if (!token) {
      throw new Error('Unauthorized');
    }
    
    return mockQuestions;
  },

  async submitExam(
    token: string, 
    answers: Map<string, string>, 
    timeTaken: number
  ): Promise<ExamResult> {
    await delay(1500);
    
    if (!token) {
      throw new Error('Unauthorized');
    }

    const details: QuestionResult[] = mockQuestions.map(question => {
      const selectedOptionId = answers.get(question.id);
      const selectedOption = selectedOptionId 
        ? question.options.find(opt => opt.id === selectedOptionId) || null
        : null;
      const correctOption = question.options.find(opt => opt.id === question.correctOptionId)!;
      const isCorrect = selectedOptionId === question.correctOptionId;

      return {
        questionId: question.id,
        questionText: question.text,
        selectedOption,
        correctOption,
        isCorrect,
        marks: question.marks
      };
    });

    const answeredCount = Array.from(answers.values()).filter(Boolean).length;
    const correctCount = details.filter(detail => detail.isCorrect).length;
    const obtainedMarks = details.reduce((total, detail) => 
      total + (detail.isCorrect ? detail.marks : 0), 0
    );

    return {
      totalQuestions: mockQuestions.length,
      answeredCount,
      correctCount,
      totalMarks: mockExamMetadata.totalMarks,
      obtainedMarks,
      percentage: (obtainedMarks / mockExamMetadata.totalMarks) * 100,
      timeTaken,
      details
    };
  }
};