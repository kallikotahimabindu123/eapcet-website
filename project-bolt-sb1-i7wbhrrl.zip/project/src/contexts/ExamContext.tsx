import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { ExamContextType, ExamState, Question, ExamMetadata, QuestionState, ExamResult } from '../types';
import { useAuth } from './AuthContext';
import { mockApi } from '../services/mockApi';

const ExamContext = createContext<ExamContextType | undefined>(undefined);

export const useExam = (): ExamContextType => {
  const context = useContext(ExamContext);
  if (!context) {
    throw new Error('useExam must be used within an ExamProvider');
  }
  return context;
};

interface ExamProviderProps {
  children: ReactNode;
}

const STORAGE_KEY = 'examState';

export const ExamProvider: React.FC<ExamProviderProps> = ({ children }) => {
  const { token } = useAuth();
  const [examState, setExamState] = useState<ExamState>({
    currentQuestionIndex: 0,
    answers: new Map(),
    questionStates: new Map(),
    timeRemaining: 0,
    isSubmitted: false,
    startTime: 0
  });
  const [questions, setQuestions] = useState<Question[]>([]);
  const [examMetadata, setExamMetadata] = useState<ExamMetadata | null>(null);
  const [result, setResult] = useState<ExamResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const currentQuestion = questions[examState.currentQuestionIndex] || null;

  // Save state to localStorage whenever it changes
  useEffect(() => {
    if (examState.startTime > 0) {
      const stateToSave = {
        ...examState,
        answers: Array.from(examState.answers.entries()),
        questionStates: Array.from(examState.questionStates.entries())
      };
      localStorage.setItem(STORAGE_KEY, JSON.stringify(stateToSave));
    }
  }, [examState]);

  const loadStoredState = (): ExamState | null => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        return {
          ...parsed,
          answers: new Map(parsed.answers || []),
          questionStates: new Map(parsed.questionStates || [])
        };
      }
    } catch (error) {
      console.error('Failed to load stored exam state:', error);
    }
    return null;
  };

  const initializeExam = async (): Promise<void> => {
    if (!token) throw new Error('Not authenticated');

    setIsLoading(true);
    setError(null);

    try {
      const [metadata, questionsData] = await Promise.all([
        mockApi.getExamMetadata(token),
        mockApi.getQuestions(token)
      ]);

      setExamMetadata(metadata);
      setQuestions(questionsData);

      // Try to restore previous state
      const storedState = loadStoredState();
      
      if (storedState && !storedState.isSubmitted) {
        setExamState(storedState);
      } else {
        // Initialize fresh exam state
        const initialQuestionStates = new Map<string, QuestionState>();
        questionsData.forEach(question => {
          initialQuestionStates.set(question.id, {
            id: question.id,
            answered: false,
            flagged: false,
            visited: false
          });
        });

        setExamState({
          currentQuestionIndex: 0,
          answers: new Map(),
          questionStates: initialQuestionStates,
          timeRemaining: metadata.timeLimitMinutes * 60,
          isSubmitted: false,
          startTime: Date.now()
        });
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to initialize exam');
    } finally {
      setIsLoading(false);
    }
  };

  const answerQuestion = (questionId: string, optionId: string) => {
    setExamState(prev => {
      const newAnswers = new Map(prev.answers);
      newAnswers.set(questionId, optionId);

      const newQuestionStates = new Map(prev.questionStates);
      const currentState = newQuestionStates.get(questionId);
      if (currentState) {
        newQuestionStates.set(questionId, {
          ...currentState,
          answered: true,
          visited: true
        });
      }

      return {
        ...prev,
        answers: newAnswers,
        questionStates: newQuestionStates
      };
    });
  };

  const flagQuestion = (questionId: string) => {
    setExamState(prev => {
      const newQuestionStates = new Map(prev.questionStates);
      const currentState = newQuestionStates.get(questionId);
      if (currentState) {
        newQuestionStates.set(questionId, {
          ...currentState,
          flagged: !currentState.flagged,
          visited: true
        });
      }

      return {
        ...prev,
        questionStates: newQuestionStates
      };
    });
  };

  const navigateToQuestion = (index: number) => {
    if (index >= 0 && index < questions.length) {
      const questionId = questions[index].id;
      
      setExamState(prev => {
        const newQuestionStates = new Map(prev.questionStates);
        const currentState = newQuestionStates.get(questionId);
        if (currentState) {
          newQuestionStates.set(questionId, {
            ...currentState,
            visited: true
          });
        }

        return {
          ...prev,
          currentQuestionIndex: index,
          questionStates: newQuestionStates
        };
      });
    }
  };

  const submitExam = async (): Promise<void> => {
    if (!token) throw new Error('Not authenticated');

    setIsLoading(true);
    setError(null);

    try {
      const timeTaken = examState.startTime > 0 
        ? Math.floor((Date.now() - examState.startTime) / 1000)
        : 0;

      const examResult = await mockApi.submitExam(token, examState.answers, timeTaken);
      
      setResult(examResult);
      setExamState(prev => ({
        ...prev,
        isSubmitted: true
      }));

      // Clear stored state after successful submission
      localStorage.removeItem(STORAGE_KEY);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to submit exam');
    } finally {
      setIsLoading(false);
    }
  };

  const updateTimer = (timeRemaining: number) => {
    setExamState(prev => ({
      ...prev,
      timeRemaining
    }));
  };

  return (
    <ExamContext.Provider
      value={{
        examState,
        questions,
        examMetadata,
        currentQuestion,
        result,
        initializeExam,
        answerQuestion,
        flagQuestion,
        navigateToQuestion,
        submitExam,
        updateTimer,
        isLoading,
        error
      }}
    >
      {children}
    </ExamContext.Provider>
  );
};