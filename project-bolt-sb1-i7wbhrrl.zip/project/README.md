# EAPCET Online Test Platform

A comprehensive online examination platform built with React, TypeScript, and Supabase for conducting secure EAPCET tests with webcam monitoring and real-time analytics.

## Features

### 🔐 **Security & Monitoring**
- Webcam monitoring with automatic photo capture
- Tab switching detection and prevention
- Right-click and keyboard shortcut blocking
- IP address and user agent tracking
- Comprehensive activity logging

### 👥 **User Management**
- Secure authentication with Supabase
- Role-based access (Admin/Student)
- Profile management with photo upload
- Real-time notifications

### 📝 **Exam Features**
- Bilingual questions (English/Telugu)
- Multiple question types support
- Excel bulk question upload
- Timer with auto-submit
- Question flagging and navigation
- Real-time progress tracking

### 📊 **Analytics & Reporting**
- Advanced performance analytics
- Question-wise difficulty analysis
- Student progress tracking
- Comprehensive admin dashboard
- Export capabilities

### 🎯 **Additional Features**
- Practice mode for students
- Certificate auto-generation
- Mobile responsive design
- Real-time data synchronization
- Offline capability support

## Getting Started

### Prerequisites

- Node.js (v16 or higher)
- npm or yarn

### Installation

1. Clone the repository
2. Install dependencies:
```bash
npm install
```

3. Start the development server:
```bash
npm run dev
```

4. Open your browser and navigate to `http://localhost:5173`

## Usage

### Login Credentials (Mock)
- **Username**: `student@example.com`
- **Password**: `password123`

### Exam Flow
1. Login with valid credentials
2. Review exam metadata on landing page
3. Start the exam
4. Navigate through questions using sidebar or navigation buttons
5. Answer questions and flag for review as needed
6. Submit exam or wait for auto-submit when timer expires
7. View detailed results

## Project Structure

```
src/
├── components/          # Reusable UI components
├── contexts/           # React Context providers
├── pages/             # Main page components
├── services/          # API and utility services
├── types/             # TypeScript type definitions
├── utils/             # Helper functions
└── data/              # Mock data and sample questions
```

## API Endpoints (Mock)

- `POST /api/auth/login` - User authentication
- `GET /api/exam/metadata` - Exam information
- `GET /api/exam/questions` - Question data
- `POST /api/exam/submit` - Submit exam answers

## Color Coding System

- **Green**: Answered questions
- **Red**: Not answered questions  
- **Orange/Yellow**: Flagged for review
- **Gray**: Not visited questions

## Building for Production

```bash
npm run build
```

## Development

The application uses:
- React 18 with hooks and functional components
- React Router for navigation
- Context API for state management
- Tailwind CSS for styling
- TypeScript for type safety
- Local storage for data persistence

## Testing

```bash
npm run test
```

## License

© 2025 Rompit Technologies. All rights reserved.